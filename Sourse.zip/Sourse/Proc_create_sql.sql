USE [TMB_ORGS]
GO

/****** Object:  Table [dbo].[SapIdTable]    Script Date: 16.08.2019 15:46:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SapIdTable](
	[SAPID] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_SapIdTable] PRIMARY KEY CLUSTERED 
(
	[SAPID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


/****** Object:  UserDefinedTableType [dbo].[SapIdTable]    Script Date: 16.08.2019 15:48:20 ******/
CREATE TYPE [dbo].[SapIdTable] AS TABLE(
	[SAPID] [nvarchar](10) NOT NULL
)
GO

/****** Object:  StoredProcedure [dbo].[x5_selectCFOsAll]    Script Date: 16.08.2019 15:48:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[x5_selectCFOsAll]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

		IF (@DateEnd IS NULL)
	    SET @DateEnd = @DateStart
	    IF (@DateEnd < @DateStart)
	     SET @DateEnd = '9999-12-31'

SELECT c.*,
            c.STATUS_ACT as 'Status',
            cl.MDM_ID AS 'ClusterID',
            cl.Name AS 'ClusterName',
            cl.CLASTER_SAP AS 'ClusterSAPID',
            d.MDM_ID AS 'DivisionID',
            d.Name AS 'DivisionName',
            d.DIVISION_SAP AS 'DivisionSAPID',
            c.FSTER as 'Format',
            c.TYPE as 'Type'
            FROM  [dbo].[CFO] c 
			INNER JOIN [dbo].[Cluster] cl ON cl.MDM_ID = c.CURR_CLUSTER 
            INNER JOIN [dbo].[Division] d ON d.MDM_ID = c.CURR_DIVISION 
			--INNER JOIN @SAPIDsToQuery SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
			ORDER BY 
			c.Name ASC
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectCFOsByDivisionSAPIDsForPlans]    Script Date: 16.08.2019 15:49:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[x5_selectCFOsByDivisionSAPIDsForPlans]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN


  IF (@DateEnd IS NULL)
	  SET @DateEnd = @DateStart
	IF (@DateEnd < @DateStart)
	  SET @DateEnd = '9999-12-31'


SET NOCOUNT ON;
 SELECT c.*,
		c.STATUS_ACT as 'Status',
		cl.MDM_ID AS 'ClusterID',
		cl.Name AS 'ClusterName',
		cl.CLASTER_SAP AS 'ClusterSAPID',
		d.MDM_ID AS 'DivisionID',
		d.Name AS 'DivisionName',
		d.DIVISION_SAP AS 'DivisionSAPID',
		c.FSTER as 'Format',
		c.TYPE as 'Type'
	FROM  [dbo].[CFO] c
	 INNER JOIN  [dbo].[Cluster] cl ON cl.MDM_ID = c.CURR_CLUSTER 
	 INNER JOIN  [dbo].[Division] d ON d.MDM_ID = c.CURR_DIVISION
	 INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
	ORDER BY 
	c.Name ASC;
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectCFOsBySAPIDs]    Script Date: 16.08.2019 15:49:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[x5_selectCFOsBySAPIDs]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
     SET NOCOUNT ON;

   	IF (@DateEnd IS NULL)
		SET @DateEnd = @DateStart
    IF (@DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'

SELECT c.*,
            c.STATUS_ACT as 'Status',
            c.CURR_CLUSTER AS 'ClusterID',
            cl.Name AS 'ClusterName',
            cl.CLASTER_SAP AS 'ClusterSAPID' FROM  [dbo].[CFO] c 
            INNER JOIN [dbo].[Cluster] cl ON cl.MDM_ID = c.CURR_CLUSTER 
			INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
			ORDER BY 
			c.Name ASC;

END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectCFOsForClusterBySAPIDs]    Script Date: 16.08.2019 15:50:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[x5_selectCFOsForClusterBySAPIDs]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

		IF (@DateEnd IS NULL)
	    SET @DateEnd = @DateStart
	    IF (@DateEnd < @DateStart)
	     SET @DateEnd = '9999-12-31'

             SELECT c.*,
              c.STATUS_ACT as 'Status',
              cl.MDM_ID AS 'ClusterID',
              cl.Name AS 'ClusterName',
              cl.CLASTER_SAP AS 'ClusterSAPID',
              d.MDM_ID AS 'DivisionID',
              d.Name AS 'DivisionName',
              d.DIVISION_SAP AS 'DivisionSAPID',
              c.FSTER as 'Format',
              c.TYPE as 'Type'
              FROM  [dbo].[CFO] c
              INNER JOIN [dbo].[Cluster] cl ON cl.MDM_ID = c.CURR_CLUSTER 
              INNER JOIN [dbo].[Division] d ON d.MDM_ID = c.CURR_DIVISION 
			  INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
			  ORDER BY 
			  c.Name ASC 
END;
GO


CREATE PROCEDURE [dbo].[x5_selectCFOsForClusterBySAPIDsForPlans]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

   	IF (@DateEnd IS NULL)
		SET @DateEnd = @DateStart
    IF (@DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'

SELECT c.*,
            c.STATUS_ACT as 'Status',
            c.CURR_CLUSTER AS 'ClusterID',
            cl.Name AS 'ClusterName',
            cl.CLASTER_SAP AS 'ClusterSAPID',
            d.MDM_ID AS 'DivisionID',
            d.Name AS 'DivisionName',
            d.DIVISION_SAP AS 'DivisionSAPID',
            c.FSTER as 'Format',
            c.TYPE as 'Type' 
			FROM  [dbo].[CFO] cc 

    INNER JOIN [dbo].[CFO] c ON c.MDM_ID = cc.MDM_ID 
     INNER JOIN [dbo].[Cluster] cl ON cl.MDM_ID = cc.CURR_CLUSTER 
       INNER JOIN [dbo].[Division] d ON d.MDM_ID = cl.DIVISION_ID
	   INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
	    ORDER BY 
		c.Name ASC
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectClustersAll]    Script Date: 16.08.2019 15:51:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[x5_selectClustersAll]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

		DECLARE @SAPIDsToQuery as SapIdTable
	
	IF (@DateStart IS NULL)
		SET @DateStart = '1753-01-01'
 	IF (@DateEnd IS NULL OR @DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'

		IF NOT EXISTS(SELECT TOP 1 * FROM @SAPIDs) 
		INSERT INTO @SAPIDsToQuery 
		SELECT DISTINCT cl.CLASTER_SAP FROM
		 [dbo].[Cluster] cl	
	ELSE
		INSERT INTO @SAPIDsToQuery SELECT DISTINCT * FROM @SAPIDs

SELECT cl.*,
           d.MDM_ID AS 'DivisionID',
           d.Name AS 'DivisionName',
           d.DIVISION_SAP AS 'DivisionSAPID' 
		   FROM 
            [dbo].[Cluster][cl] 
           INNER JOIN [dbo].[Division] [d] ON[d].MDM_ID = cl.DIVISION_ID 
		   INNER JOIN @SAPIDsToQuery SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
		   ORDER BY 
		   cl.Name ASC
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectClustersByDivisionSAPIDs]    Script Date: 16.08.2019 15:52:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[x5_selectClustersByDivisionSAPIDs]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

	IF (@DateEnd IS NULL)
		SET @DateEnd = @DateStart
    IF (@DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'

SELECT cl.*,
          d.MDM_ID AS 'DivisionID',
          d.Name AS 'DivisionName',
          d.DIVISION_SAP AS 'DivisionSAPID'
		  FROM 
           [dbo].[CLUSTER] cl 
          INNER JOIN [dbo].[DIVISION] d ON d.MDM_ID = cl.DIVISION_ID
		  INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = d.DIVISION_SAP
		   ORDER BY 
		   cl.Name ASC
END
GO

/****** Object:  StoredProcedure [dbo].[x5_selectClustersBySAPIDs]    Script Date: 16.08.2019 15:52:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[x5_selectClustersBySAPIDs]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

    IF (@DateEnd IS NULL)
		SET @DateEnd = @DateStart
    IF (@DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'


SELECT cl.*,
             d.MDM_ID AS 'DivisionID',
             d.Name AS 'DivisionName',
             d.DIVISION_SAP AS 'DivisionSAPID'
			  FROM 
              [dbo].[CLUSTER] cl 
             INNER JOIN [dbo].[Division] d ON d.MDM_ID = cl.DIVISION_ID 
			 INNER JOIN @SAPIDs SAPIDs ON SAPIDs.SAPID = cl.CLASTER_SAP
		     ORDER BY 
		     cl.Name ASC

             
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectDivisionsAll]    Script Date: 16.08.2019 15:53:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[x5_selectDivisionsAll]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @SAPIDsToQuery as SapIdTable

	IF (@DateEnd IS NULL)
	    SET @DateEnd = @DateStart
	    IF (@DateEnd < @DateStart)
	     SET @DateEnd = '9999-12-31'

		 IF NOT EXISTS(SELECT TOP 1 * FROM @SAPIDs) 
		INSERT INTO @SAPIDsToQuery 
		SELECT DISTINCT d.DIVISION_SAP FROM
		[dbo].[Division] d		
	ELSE
		INSERT INTO @SAPIDsToQuery SELECT DISTINCT * FROM @SAPIDs

SELECT d.* 
FROM  [dbo].[DIVISION] d 
INNER JOIN @SAPIDsToQuery SAPIDs ON SAPIDs.SAPID = d.DIVISION_SAP
ORDER BY 
d.Name ASC
END;
GO

/****** Object:  StoredProcedure [dbo].[x5_selectDivisionsBySAPIDs]    Script Date: 16.08.2019 15:55:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[x5_selectDivisionsBySAPIDs]
    @SAPIDs as SapIdTable READONLY,
	@DateStart date,
	@DateEnd date = null
AS
BEGIN
    SET NOCOUNT ON;

	DECLARE @SAPIDsToQuery as SapIdTable

	IF (@DateEnd IS NULL)
		SET @DateEnd = @DateStart
    IF (@DateEnd < @DateStart)
		SET @DateEnd = '9999-12-31'

		IF NOT EXISTS(SELECT TOP 1 * FROM @SAPIDs) 
		INSERT INTO @SAPIDsToQuery 
		SELECT DISTINCT d.DIVISION_SAP FROM
		[dbo].[Division] d		
	ELSE
		INSERT INTO @SAPIDsToQuery SELECT DISTINCT * FROM @SAPIDs
		

    SELECT d.* 
	FROM  [dbo].[DIVISION] d
	INNER JOIN @SAPIDsToQuery SAPIDs ON SAPIDs.SAPID = d.DIVISION_SAP

END;
GO